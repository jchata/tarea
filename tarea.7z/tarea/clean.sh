#!/usr/bin/env sh

docker-compose stop
docker-compose kill
docker-compose rm -f